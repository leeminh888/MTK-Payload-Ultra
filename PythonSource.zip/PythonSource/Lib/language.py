disclaimer = """\nI am not a developer of MTK-Payload,
but I redesigned the project and can now be used without installing Python.
I also made it so that the program does not close in case
of an exception (This will allow you to read the error)
\nMTK-Payload developers:
    @chaosmaster - https://github.com/chaosmaster
    @Dinolek - https://github.com/Dinolek\n
Developer mod for MTK-Payload:
    @Groiznyi-Studio - https://github.com/Groiznyi-Studio\n
*** I hope for your understanding ***\n"""

toRun = "Press enter to run payload..."
notConfig = ["Config file ", " doesn't exist"]
notDConfig = "Default config is missing"
watchdogTimer = "Disabling watchdog timer"
disProtect = "Disabling protection"
testMod = "Test mode, testing "
insecureDevice = "Insecure device, sending payload using send_DA"
protectOff = "Protection disabled"
unexpectedResult = "Unexpected result "
errorPayload = "Payload did not reply"
dumpBrom = "Found send_dword, dumping bootrom to "
notPayload = ["Payload file ", " doesn't exist"]
hwCode = "Device hw code: "
hwCode2 = "Device hw sub code: "
hwVersion = "Device hw version: "
swVersion = "Device sw version: "
securityBoot = "Device secure boot: "
linkAuth = "Device serial link authorization: "
downloadAgent = "Device download agent authorization"
preloadMod = "Found device in preloader mode, trying to crash..."

def initRu():
    global disclaimer
    disclaimer = """Я не разработчик MTK-Payload,
но я переработал проект, и теперь его можно использовать без установки Python.
\nРазработчики MTK-Payload:
    @chaosmaster - https://github.com/chaosmaster
    @Dinolek - https://github.com/Dinolek\n
Разработчик мода для MTK-Payload:
    @Groiznyi-Studio - https://github.com/Groiznyi-Studio\n
*** Надеюсь на понимание ***\n"""

    global toRun
    toRun = "Нажмите Enter чтобы запустить payload..."
    global notConfig
    notConfig = ["Файл конфигурации ", " не найден"]
    global notDConfig
    notDConfig = "Файл с конфигурацией по умолчанию не найден"
    global watchdogTimer
    watchdogTimer = "Отключение защитного таймера"
    global disProtect
    disProtect = "Отключение защиты"
    global testMod
    testMod = "Тестирую "
    global insecureDevice
    insecureDevice = "Ошибка payload пробую отправить еще раз с помощью send_DA"
    global protectOff
    protectOff = "Защита отключена"
    global unexpectedResult
    unexpectedResult = "Неожиданный результат "
    global errorPayload
    errorPayload = "Payload не отвечает"
    global dumpBrom
    dumpBrom = "Найден send_dword, сохранение bootrom в "
    global notPayload
    notPayload = ["Payload ", " не найден"]
    global hwCode
    hwCode = "Hw код: "
    global hwCode2
    hwCode2 = "Hw2 код: "
    global hwVersion
    hwVersion = "Версия hw: "
    global swVersion
    swVersion = "Версия sw: "
    global securityBoot
    securityBoot = "Безопасная загрузка: "
    global linkAuth
    linkAuth = "Авторизация устройства: "
    global downloadAgent
    downloadAgent = "Агент для загрузки: "
    global preloadMod
    preloadMod = "Обнаружено устройство в режиме preload"
    global statusIs
